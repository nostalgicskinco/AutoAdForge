
// Queue new scheduled tasks (emails or social posts)

const { Queue } = require('bullmq');
const Redis = require('ioredis');

const redisConnection = new Redis({ host: 'localhost', port: 6379 });
const queue = new Queue('scheduleQueue', { connection: redisConnection });

async function scheduleJob(type, data, delayMs) {
    await queue.add(type, data, {
        delay: delayMs,
        attempts: 3
    });
}

// Example usage:
// scheduleJob('sendEmail', { to: 'user@example.com', subject: 'Welcome!' }, 60000);

module.exports = scheduleJob;

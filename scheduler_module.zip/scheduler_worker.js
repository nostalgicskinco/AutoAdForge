
// Node.js worker using BullMQ and Redis for email/post scheduling

const { Worker, Queue } = require('bullmq');
const Redis = require('ioredis');

const redisConnection = new Redis({ host: 'localhost', port: 6379 });
const queueName = 'scheduleQueue';

const worker = new Worker(queueName, async job => {
    console.log(`Processing job: ${job.name}`);
    if (job.name === 'sendEmail') {
        // Send email logic
        console.log('Sending email:', job.data);
    } else if (job.name === 'postSocial') {
        // Post to social media
        console.log('Posting on social media:', job.data);
    }
}, { connection: redisConnection });

worker.on('completed', job => {
    console.log(`Job completed: ${job.id}`);
});

worker.on('failed', (job, err) => {
    console.error(`Job failed: ${job.id}`, err);
});

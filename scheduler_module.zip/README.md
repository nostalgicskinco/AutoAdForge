
# Email & Post Scheduler (BullMQ + Redis)

## Setup

1. Start Redis server:
```bash
docker run -p 6379:6379 redis
```

2. Install dependencies:
```bash
npm install bullmq ioredis
```

3. Run the worker:
```bash
node scheduler_worker.js
```

4. Schedule a job:
```bash
node -e "require('./schedule_job')('sendEmail', { to: 'user@example.com' }, 60000)"
```

This setup supports cron-like scheduling and retry logic for email and post jobs.

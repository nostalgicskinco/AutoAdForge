const express = require('express');
const app = express();
app.use(express.json());
app.use('/api', require('./routes/campaignRoutes'));
app.use('/api', require('./routes/postRoutes'));
app.use('/api', require('./routes/webhookRoutes'));
app.get('/', (req, res) => res.send('API Running'));
module.exports = app;
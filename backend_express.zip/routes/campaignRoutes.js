const express = require('express');
const router = express.Router();
const { launchCampaign } = require('../controllers/campaignController');
router.post('/launch-campaign', launchCampaign);
module.exports = router;
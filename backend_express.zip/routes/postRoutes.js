const express = require('express');
const router = express.Router();
const { schedulePost } = require('../controllers/postController');
router.post('/schedule-post', schedulePost);
module.exports = router;
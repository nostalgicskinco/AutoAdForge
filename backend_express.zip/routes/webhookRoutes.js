const express = require('express');
const router = express.Router();
const { receiveUpdate } = require('../controllers/webhookController');
router.post('/webhook', receiveUpdate);
module.exports = router;
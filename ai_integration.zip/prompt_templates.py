
# Prompt structures for different types of AI-generated content

def ad_copy_prompt(product_name, benefits, tone="funny"):
    return f"""
You are an expert ad copywriter. Write 3 high-converting ad headlines and descriptions for a product called {product_name}.
Benefits include: {benefits}.
Tone: {tone}.
Make it punchy, scroll-stopping, and optimized for Facebook, Instagram, and Google Ads.
"""

def email_prompt(subject_line, main_offer):
    return f"""
You're an ecommerce email expert. Write a high-performing marketing email.
Subject: {subject_line}
Main Offer: {main_offer}
Include: Preview text, body copy, and a CTA button text.
"""

def caption_prompt(product_name, vibe="funny"):
    return f"""
You are a social media growth expert. Write 3 viral Instagram captions for a product called {product_name}.
Keep it {vibe}, short, and use 3 relevant hashtags.
"""

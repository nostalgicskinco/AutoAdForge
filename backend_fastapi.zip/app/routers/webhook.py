from fastapi import APIRouter

router = APIRouter()

@router.post('/webhook')
def receive_webhook():
    return {'message': 'Webhook received'}

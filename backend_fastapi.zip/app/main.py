from fastapi import FastAPI
from app.routers import campaign, post, webhook

app = FastAPI()

app.include_router(campaign.router, prefix='/api')
app.include_router(post.router, prefix='/api')
app.include_router(webhook.router, prefix='/api')

@app.get('/')
def root():
    return {'message': 'API Running'}
